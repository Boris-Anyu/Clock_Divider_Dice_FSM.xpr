module bcd_to_7seg(A, X);

    input  [3:0] A;
    output [7:1] X;

    reg [7:1] X;

    always @(*)
        case (A)
            4'd0: X = 7'b0000001;
            4'd1: X = 7'b1001111;
            4'd2: X = 7'b0010010;
            4'd3: X = 7'b0000110;
            4'd4: X = 7'b1001100;
            4'd5: X = 7'b0100100;
            4'd6: X = 7'b0100000;
            4'd7: X = 7'b0001111;
            4'd8: X = 7'b0000000;
            4'd9: X = 7'b0000100;
            default: X = 7'b1111111;
        endcase

endmodule