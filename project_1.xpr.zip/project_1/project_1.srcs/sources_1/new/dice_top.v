`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: St. Cloud State University
// Author: Boris Anyu
//
// Module Name: dice_top
// Project Name: ECE 320 Lab #7
// Description: Top level. Two dice, each a 1 to 6 counter on its own divided clock.
//              Connects the dice to the seven-segment decoders and the display driver.
//////////////////////////////////////////////////////////////////////////////////


module dice_top(CLK100MHz, reset, roll, clk_die1, clk_die2, seg, an);
 
        //inputs
        input CLK100MHz;
        input reset;
        input roll;
 
        //output
        output clk_die1;
        output clk_die2;
        output [0:7] seg;
        output [7:0] an;
 
        //wire
        wire [2:0] die1, die2;
        wire [1:7] X1, X0;
 
        clk_div #(.n(4), .logn(2)) uut1(
            .clock(CLK100MHz),
            .reset(reset),
            .clk_out(clk_die1)
            );
 
        clk_div #(.n(6), .logn(3)) uut2(
            .clock(CLK100MHz),
            .reset(reset),
            .clk_out(clk_die2)
            );
 
        counter_1to6 uut3(
            .Enable(roll),
            .clock(clk_die1),
            .reset(reset),
            .count(die1)
            );
 
        counter_1to6 uut4(
            .Enable(roll),
            .clock(clk_die2),
            .reset(reset),
            .count(die2)
            );
 

        bcd_to_7seg uut5(
            .A({1'b0, die2}),
            .X(X0)
            );

        bcd_to_7seg uut6(
            .A({1'b0, die1}),
            .X(X1)
            );

        sSegDisplay_8 uut7(
             .ck(CLK100MHz),
             .digit0(X0),
             .digit1(7'b111_1111),
             .digit2(7'b111_1111),
             .digit3(X1),
             .digit4(7'b111_1111),
             .digit5(7'b111_1111),
             .digit6(7'b111_1111),
             .digit7(7'b111_1111),
             .seg(seg),
             .an(an)
              );

endmodule