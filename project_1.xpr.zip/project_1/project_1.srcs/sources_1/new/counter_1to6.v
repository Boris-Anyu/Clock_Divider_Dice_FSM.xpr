`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: St. Cloud State University
// Author: Boris Anyu
//
// Create Date: 10/27/2026
// Module Name: counter_1to6
// Project Name: ECE 320 Lab #7
// Target Devices: Nexys A7
// Description: Moore FSM that counts 1 to 6 only when Enable is high.
//////////////////////////////////////////////////////////////////////////////////


module counter_1to6(Enable, reset, clock, count);

    input Enable, reset, clock;
    
    output reg [2:0] count;
    
    reg [2:0] present, next;
    
    parameter S0=3'b000, S1=3'b001, S2=3'b010, S3=3'b011, S4=3'b100, S5=3'b101;
    
     //Next State logic
    always @(present, Enable)
        begin
            case(present)
                S0: if (Enable)
                         next = S1;
                    else
                         next = S0;
 
                S1: if (Enable)
                         next = S2;
                    else
                         next = S1;
 
                S2: if (Enable)
                         next = S3;
                    else
                         next = S2;
 
                S3: if (Enable)
                         next = S4;
                    else
                         next = S3;
 
                S4: if (Enable)
                         next = S5;
                    else
                         next = S4;
 
                S5: if (Enable)
                         next = S0;
                    else
                         next = S5;
 
                default: next = S0;
 
            endcase
        end


  //state transition
    always @(posedge clock or posedge reset)
        begin
            if (reset)
                present <= S0;
            else
                present <= next;
        end
        
        
    //Output logic
    always @(*) begin
 
        case(present)
 
            S0: count = 1;
 
            S1: count = 2;
 
            S2: count = 3;
 
            S3: count = 4;
 
            S4: count = 5;
 
            S5: count = 6;
 
            default: count = 1;
 
        endcase
        end


endmodule
