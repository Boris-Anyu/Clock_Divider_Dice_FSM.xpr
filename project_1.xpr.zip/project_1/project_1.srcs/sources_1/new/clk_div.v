`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: St. Cloud State University
// Author: Boris Anyu
//
// Module Name: clk_div
// Project Name: ECE 320 Lab #7
// Target Devices: Nexys A7
// Description: Clock divider. Output frequency = input frequency / n.
//////////////////////////////////////////////////////////////////////////////////


module clk_div(clock, reset, clk_out);

    //Parameters
    parameter n = 4;
    parameter logn = 2;

    //Inputs
    input clock;
    input reset;

    //Outputs
    output reg clk_out;

    //Registers
    reg [logn-1:0] count;
    reg [2:0] present_state, next;

    //Parameters: State encodes
    parameter S0=3'b000, S1=3'b001;

    //Initialization 
    initial begin
        count = 0;
        clk_out = 1;
        present_state = S0;
    end

    //Next State logic
    always @(present_state, count)
        begin
            case(present_state)
                S0: if (count == (n/2)-1)
                         next = S1;
                    else
                         next = S0;

                S1: if (count == n-2)
                         next = S0;
                    else
                         next = S1;

                default: next = S0;

            endcase
        end

    //state transition
    always @(posedge clock or posedge reset)
        begin
            if (reset)
                present_state <= S0;
            else
                present_state <= next;
        end

    //Register Transfer Operation
    always @(posedge clock or posedge reset)
        begin
            if (reset)
                begin
                    clk_out <= 1;
                    count   <= 0;
                end

        else begin
            case(present_state)
                S0: if (count == (n/2)-1)
                        begin
                            clk_out <= 0;
                        end
                    else
                        begin
                            count <= count + 1;
                        end

                S1: if (count == n-2)
                        begin
                            clk_out <= 1;
                            count   <= 0;
                        end
                    else
                        begin
                            count <= count + 1;
                        end

            endcase
            end
            end

endmodule