`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: St. Cloud State University
// Author: Boris Anyu
//
// Module Name: clk_div_TB
// Project Name: ECE 320 Lab #7
// Description: Testbench for clk_divider. 100MHz input, 25MHz output.
//////////////////////////////////////////////////////////////////////////////////


module clk_div_TB();

    reg reset, clock;
    
    wire clk_out;
    
    clk_div #(.n(4), .logn(2)) uut(
        .reset(reset),
        .clock(clock),
        .clk_out(clk_out)
        );
        
   
    initial begin
        clock = 0;
     end
 
     always begin
        #5 clock = ~clock;
        end
 
     initial begin
        reset = 1;
 
        #22 reset = 0;
 
        #400;
 
        end
 
endmodule
