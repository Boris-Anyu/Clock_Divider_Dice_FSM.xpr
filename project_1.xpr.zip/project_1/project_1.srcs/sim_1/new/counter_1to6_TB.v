`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: St. Cloud State University
// Author: Boris Anyu
//
// Module Name: counter_1to6_TB
// Project Name: ECE 320 Lab #7
// Description: Testbench for counter_1to6.
//////////////////////////////////////////////////////////////////////////////////
 


module counter_1to6_TB( );

        reg Enable, reset, clock;
        
        wire [2:0] count;
        
        counter_1to6 uut(
            .Enable(Enable),
            .reset(reset),
            .clock(clock),
            .count(count)
            );
            
      initial begin
        clock = 0;
     end
 
     always begin
        #50 clock = ~clock;
        end
 
     initial begin
        reset = 1;
        Enable = 0;
 
        #125 reset = 0;
        
        Enable = 1; #1000;
 
        Enable = 0; #300;
 
        Enable = 1; #400;
 
        reset = 1; #100;
        reset = 0; #200;
 
        end
 
endmodule  

